=== Flickr Photos===
Contributors: incirusa
Donate link: http://www.iwasinturkey.com/buy-us-a-beer
Tags: flickr,photos, widget,plugin,sidebar,images,photo,rss,flickr photos
Requires at least: 2.8
Tested up to: 3.0
Stable tag: 3.0
Displays Flickr photos based on your settings.

== Description ==
Flickr Photos plugin is the perfect and easiest way to show your Flickr pictures on your site. You can also show any Flickr group or public photos too.

Thanks to [scott laplant](http://scottlaplant.org) for his supports.

= English =
* Displays Flickr photos based on your settings. 
* Ability to choose between User, Group or All Public Photos
* Tag function let you choose tagged photos base on your keyword
* A sample work can be seen here -> [Turkey Photos](http://www.iwasinturkey.com/photos "Turkey Photos")
* [WordPress Plugins](http://www.lycie.com/category/wordpress "WordPress Plugins")

= Turkce =
* En fazla 10 tane Flickr resmini istenilen "tag(anahtar kelime)"e gore yayimlama imkani veriyor.
* [WordPress Eklentileri](http://www.mutlubalik.com/mutlubalik/wordpress "WordPress Eklentileri")

== Installation ==

* Download 'simpleflickrphotos.zip' to your computer and unzip it.
* Upload `simpleflickrphotos` folder to the `/wp-content/plugins/` directory
* Once you upload the plugin activate it through the 'Plugins' menu in WordPress
* Finally, add the widget to your sidebar through the 'Appearance > Wigdets' menu
* Go to your widget and adjust the settings

== Frequntly Asked Qustions ==


== Screenshots ==

1. Medium size photos
2. Thumbnail size photos
3. Square photos
4. Settings

== Changelog ==

= v2.0 09.07.2009 =
Major functions added.
Simple code used instead of heavy javascript.
Plugin is not simple anymore.


= v1.1 03.07.2009 =

minor corrections with the readme.txt

= v1.0 02.07.2009 =

initial release